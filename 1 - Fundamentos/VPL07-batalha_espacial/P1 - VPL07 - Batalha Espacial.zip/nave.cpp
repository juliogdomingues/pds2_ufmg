#include <iostream>
#include <limits>
#include <math.h>
#include <vector>


#include "ponto.h"
#include "nave.h"

Nave::Nave(Ponto2D posicao, double forca, double energia) {    
    _posicao = posicao;
    _forca = forca;
    _energia = 100.0;
}

Ponto2D Nave::get_posicao() {
    return _posicao;
}

double Nave::get_posicao_x() {
    return _posicao.get_x();
}

double Nave::get_posicao_y() {
    return _posicao.get_y();
}

double Nave::get_forca() {
    return _forca;
}

double Nave::get_energia() {
    return _energia;
}

void Nave::mover(double dx, double dy) {
    double new_x = _posicao.get_x() + dx;
    double new_y = _posicao.get_y() + dy;
    _posicao.modify_ponto(new_x, new_y);
}

double Nave::calcular_distancia(Nave nave) {
    double distancia_naves = _posicao.calcular_distancia(nave.get_posicao());
    return distancia_naves;
}

int Nave::determinar_indice_nave_mais_proxima(Nave naves[], int n) {
    int indice_mais_proxima = -1;
    double distancia_mais_proxima = std::numeric_limits<double>::max();
    for (int i = 0; i < n; i++) {
        if (this != &naves[i]) {
            double distancia = this->calcular_distancia(naves[i]);
            if (distancia < distancia_mais_proxima) {
                distancia_mais_proxima = distancia;
                indice_mais_proxima = i;
            }
        }
    }
    return indice_mais_proxima;
}

void Nave::atacar(Nave naves[], int n) {
    Nave& nave_ataca = *this;
    int indice_nave_atacada = nave_ataca.determinar_indice_nave_mais_proxima(naves, n);
    Nave& nave_atacada = naves[indice_nave_atacada];
    
    double dano = (nave_ataca.get_forca() * 100) / nave_ataca.calcular_distancia(nave_atacada);
    if (dano > 30) dano = 30;
    
    nave_atacada._energia -= dano;
    if (nave_atacada.get_energia() <= 50) std::cout << "Energia baixa!" << std::endl;
}

void Nave::imprimir_status() {
    std::cout << get_posicao_x() << " " << get_posicao_y() << " " << get_energia() << std::endl;
}