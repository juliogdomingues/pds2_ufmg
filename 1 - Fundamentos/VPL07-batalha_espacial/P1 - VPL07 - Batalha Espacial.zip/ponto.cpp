#include <math.h>

#include "ponto.h"

Ponto2D::Ponto2D(double x, double y) {
    _x = x;
    _y = y;
}

double Ponto2D::get_x() {
    return _x;
}

double Ponto2D::get_y() {
    return _y;
}

void Ponto2D::modify_ponto(double x, double y) {
    _x = x;
    _y = y;
}

double Ponto2D::calcular_distancia(Ponto2D ponto) {
    double distancia = sqrt(pow((ponto.get_x() - _x), 2) + pow((ponto.get_y() - _y), 2));
    return distancia;
}

