#ifndef VPL7_PONTO_H
#define VPL7_PONTO_H

class Ponto2D {
    private:
        double _x;
        double _y;
        
    public:
        Ponto2D(double x = 0, double y = 0);
        
        double get_x();
    
        double get_y();
        
        void modify_ponto (double x, double y);
        
        double calcular_distancia(Ponto2D ponto);
};

#endif