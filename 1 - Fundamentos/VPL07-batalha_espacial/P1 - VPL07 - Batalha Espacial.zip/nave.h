#ifndef VPL7_NAVE_H
#define VPL7_NAVE_H

#include <math.h>
#include "ponto.h"

class Nave {
    private:
        Ponto2D _posicao;
        double _forca;
        double _energia;
        
    public:
        Nave(Ponto2D posicao = Ponto2D(), double forca = 1.0, double energia = 100.0);

        Ponto2D get_posicao();

        double get_posicao_x();
        
        double get_posicao_y();
        
        double get_forca();
        
        double get_energia();

        void mover(double dx, double dy);
        
        double calcular_distancia(Nave nave);
        
        int determinar_indice_nave_mais_proxima(Nave naves[], int n);
    
        void atacar(Nave naves[], int n);
        
        void imprimir_status();
    
};

#endif