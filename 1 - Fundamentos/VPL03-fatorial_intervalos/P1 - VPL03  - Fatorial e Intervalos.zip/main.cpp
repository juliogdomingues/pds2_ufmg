#include <iostream>
#include <math.h>
using namespace std;

/**
 * @brief Calcula o fatorial de um numero inteiro
 * 
 * Esta funcao nao faz tratamento de erros: se o numero passado como parametro
 * for igual ou menor a zero, entao ela retorna o valor 1.
 * 
 * @param arg O numero cujo fatorial sera calculado
 * @return unsigned O valor do fatorial de arg. Se arg for igual ou menor a
 * zero, entao o valor retornado deve ser 1.
 */
unsigned factorial(int arg) {
    unsigned int arg_factorial;
    if (arg <= 0) return 1;
    else {
        arg_factorial = arg * factorial(arg - 1);
        return arg_factorial;
    }
    return 0;
}

/**
 * @brief Conta a quantidade de inteiros em um certo intervalo.
 * 
 * O intervalo eh formado por dois numeros de ponto flutuante (doubles). A
 * contagem eh inclusiva. Assim, entre 1.0 e 3.0 existem tres inteiros
 * (1, 2 e 3), mas entre 0.2 e 0.9 nao existe nenhum.
 * 
 * @param start O inicio do intervalo
 * @param end O final do interval
 * @return unsigned O numero de inteiros contidos dentro do intervalo
 * (inclusive)
 */
unsigned interval(double start, double end) {
    int start_int = (int) ceil(start);
    int end_int = (int) floor(end);
    int counter = max(0, end_int - start_int + 1);
    return counter;
}

int main() {
  char test = 0;
  cin >> test;
  switch (test) {
    case 'f': {
      int arg = 0;
      std::cin >> arg;
      std::cout << factorial(arg) << endl;
    }
    break;
    case 'i': {
      double arg0 = 0;
      double arg1 = 0;
      cin >> arg0 >> arg1;
      cout << interval(arg0, arg1) << endl;
    }
    break;
  }
}