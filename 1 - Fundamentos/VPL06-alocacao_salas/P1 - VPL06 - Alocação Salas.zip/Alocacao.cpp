#include <iostream>
#include <string>

#include "Alocacao.hpp"

Alocacao::Alocacao (std::string dia, std::string horario, std::string sala) {
    _dia = dia;
    _horario = horario;
    _sala = sala;
}

std::string Alocacao::get_dia() {
    return _dia;
}
    
std::string Alocacao::get_horario() const {
    return _horario;
}

std::string Alocacao::get_sala() {
    return _sala;
}

void Alocacao::imprimir_dados() {
    std::cout << _dia << " " << _horario << " " << _sala << " " << std::endl;
}