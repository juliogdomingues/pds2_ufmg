#include <algorithm>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#include "Alocacao.hpp"
#include "Disciplina.hpp"
#include "QuadroAlocacao.hpp"

QuadroAlocacao::QuadroAlocacao() {
    _quadro = std::map<std::string, Disciplina>{};
}

void QuadroAlocacao::inserir_alocacao(std::string codigo, std::string nome, std::string dia, std::string horario, std::string sala) {
    if (_quadro.find(codigo) == _quadro.end()) {
        _quadro[codigo] = Disciplina(codigo, nome);
    }
    _quadro[codigo].inserir_alocacao(dia, horario, sala);
}

void QuadroAlocacao::remover_alocacao_disciplina(std::string codigo, std::string horario) {
    _quadro[codigo].remover_alocacao(horario);
}

std::vector<Disciplina> QuadroAlocacao::recuperar_disciplinas_mais_ofertadas() {
    std::vector<Disciplina> mais_ofertadas;
    int maxAlocacoes = 0;

    for (auto& it : _quadro) {
        int numAlocacoes = it.second.get_alocacoes().size();
        if (numAlocacoes > maxAlocacoes) {
            maxAlocacoes = numAlocacoes;
            mais_ofertadas.clear();
            mais_ofertadas.push_back(it.second);
        } else if (numAlocacoes == maxAlocacoes) {
            mais_ofertadas.push_back(it.second);
        }
    }
    return mais_ofertadas;
}

// imprimir_alocacao_completa(): imprime todo o quadro de alocação.
// As disciplinas devem estar ordenadas pelo código, e as alocações pelo horário da oferta.
void QuadroAlocacao::imprimir_alocacao_completa() {
    for (auto& it : _quadro) {
        std::vector<Alocacao> alocacoes = it.second.get_alocacoes();
        std::sort(alocacoes.begin(), alocacoes.end(), [](const Alocacao& a1, const Alocacao& a2) {
            return a1.get_horario() < a2.get_horario();
        });

        for (auto& a : alocacoes) {
            std::cout << it.second.get_codigo() << " " << it.second.get_nome() << " " << a.get_dia() << " " << a.get_horario() << " " << a.get_sala() << std::endl;
        }
    }
}