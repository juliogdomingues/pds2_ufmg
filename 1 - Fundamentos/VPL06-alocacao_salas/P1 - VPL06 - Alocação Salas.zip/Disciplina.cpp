#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

#include "Alocacao.hpp"
#include "Disciplina.hpp"

Disciplina::Disciplina() {
}

Disciplina::Disciplina(std::string codigo, std::string nome) {
    _codigo = codigo;
    _nome = nome;
}

std::string Disciplina::get_codigo() {
    return _codigo;
}

std::string Disciplina::get_nome() {
    return _nome;
}

std::vector<Alocacao> Disciplina::get_alocacoes() const {
    return _alocacoes;
}

void Disciplina::inserir_alocacao(std::string dia, std::string horario, std::string sala) {
    _alocacoes.push_back(Alocacao(dia, horario, sala));
}

void Disciplina::remover_alocacao(std::string horario) {
    unsigned int i;
    for (i = 0; i < _alocacoes.size(); i++) {
        if (_alocacoes[i].get_horario() == horario) {
            break;
        }
    }
    if (i != _alocacoes.size()) {
        _alocacoes.erase(_alocacoes.begin() + i);
    }
}

void Disciplina::imprimir_alocacao() {
    std::vector<Alocacao> alocacoes_ordenadas = _alocacoes;    
    std::sort(alocacoes_ordenadas.begin(), alocacoes_ordenadas.end(), [](const Alocacao& a1, const Alocacao& a2) {
        return a1.get_horario() < a2.get_horario();
    });

    for (unsigned int i = 0; i < alocacoes_ordenadas.size(); i++) {
        std::cout << _codigo << " " << _nome << " " << alocacoes_ordenadas[i].get_dia() << " "
                  << alocacoes_ordenadas[i].get_horario() << " " << alocacoes_ordenadas[i].get_sala() << std::endl;
    }
}