#ifndef VPL6_DISCIPLINA
#define VPL6_DISCIPLINA

#include <iostream>
#include <string>
#include <vector>
#include "Alocacao.hpp"

class Disciplina {
    private:
        std::string _codigo;
        std::string _nome;
        std::vector<Alocacao> _alocacoes;
        
    public:

        Disciplina();

        Disciplina(std::string codigo, std::string nome);

        std::string get_codigo();

        std::string get_nome();

        std::vector<Alocacao> get_alocacoes() const;
        
        void inserir_alocacao(std::string dia, std::string horario, std::string sala);
        
        void remover_alocacao(std::string horario);
        
        void imprimir_alocacao();
};

#endif