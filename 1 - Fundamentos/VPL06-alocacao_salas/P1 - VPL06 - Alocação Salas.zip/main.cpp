
#include <algorithm>
#include <iostream>
#include <map>
#include <string>
#include <vector>

#include "Alocacao.hpp"
#include "Disciplina.hpp"
#include "QuadroAlocacao.hpp"

// NÃO ALTERE ESSA LINHA
#include "avaliacao_basica_alocacao.hpp"


int main() {
    QuadroAlocacao quadro;
    char comando;
    while (std::cin >> comando) {
        switch (comando) {
            case 'a':
            {
                std::string codigo, nome, dia, horario, sala;
                std::cin >> codigo >> nome >> dia >> horario >> sala;
                quadro.inserir_alocacao(codigo, nome, dia, horario, sala);
                break;
            }
            case 'm':
            {
                std::vector<Disciplina> disciplinas_mais_ofertadas = quadro.recuperar_disciplinas_mais_ofertadas();
                for (Disciplina disciplina : disciplinas_mais_ofertadas) {
                    disciplina.imprimir_alocacao();
                }
                break;
            }
            case 'r':
            {
                std::string codigo, horario;
                std::cin >> codigo >> horario;
                quadro.remover_alocacao_disciplina(codigo, horario);
                break;
            }
            case 'p':
            {
                quadro.imprimir_alocacao_completa();
                break;
            }
            case 'b':
            {
                avaliacao_basica();
                break;
            }
            default:
            {
                break;
            }
        }
    }
    return 0;
}