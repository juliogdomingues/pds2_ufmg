#ifndef VPL6_ALOCACAO
#define VPL6_ALOCACAO

#include <iostream>
#include <string>

class Alocacao {
    private:
        std::string _dia;
        std::string _horario;
        std::string _sala;
        
    public:
        Alocacao (std::string dia, std::string horario, std::string sala);
        std::string get_dia();
        std::string get_horario() const;
        std:: string get_sala();
        void imprimir_dados();
};

#endif