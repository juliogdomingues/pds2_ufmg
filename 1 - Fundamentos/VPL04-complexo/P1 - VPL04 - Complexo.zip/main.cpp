#include <iostream>
#include <cmath>
#include <utility>

using namespace std;

// Tipo abastrato de dados que representa um número complexo. 
class Complexo {
  // Atributos.
  private:
    double real;
    double imag;

  // Métodos.
  public:
    // Construtor.
    Complexo(double real, double imag) {
      this->real = real;
      this->imag = imag;
    }

    double get_real() {
      return real;
    }

    double get_imag() {
      return imag;
    }

    double modulo() {
      double mod;
      mod = sqrt(pow(real, 2)+pow(imag, 2));
      return mod;
    }
    Complexo conjugado() {
      Complexo conj(real, -imag);
      return conj;
    }
    Complexo inverso() {
      double denom = real*real + imag*imag;
      Complexo inverso(real/denom, -imag/denom);
      return inverso;
    }
    Complexo soma(Complexo y) {
      double real_soma = real + y.real;
      double imag_soma = imag + y.imag;
      Complexo somatorio = Complexo(real_soma, imag_soma);
      return somatorio;
    }
    Complexo subtrair(Complexo y) {
      double real_sub = real - y.real;
      double imag_sub = imag - y.imag;
      Complexo subtracao = Complexo(real_sub, imag_sub);
      return subtracao;
    }
    Complexo multiplicar(Complexo y) {
      double produto_real = (real * y.real) - (imag * y.imag);
      double produto_imag = (real * y.imag) + (imag * y.real);
      Complexo produto = Complexo(produto_real, produto_imag);
      return produto;
    }
    Complexo dividir(Complexo y) {
      double quociente_real = (real * y.real + imag * y.imag) / (pow(y.real, 2) + pow(y.imag, 2));
      double quociente_imag = (imag * y.real - real * y.imag) / (pow(y.real, 2) + pow(y.imag, 2));
      Complexo quociente = Complexo(quociente_real, quociente_imag);
      return quociente;
    }
};

pair<Complexo, Complexo> raizes(double a, double b, double c) {
  double delta = pow(b, 2)-4*a*c;
  int i = 0;
  double real_1, real_2, imag_1, imag_2 = 0;

  real_1 = (-b+sqrt(delta))/(2*a);
  real_2 = (-b-sqrt(delta))/(2*a);

  if (delta < 0) {
    delta = sqrt(-delta);
    i = 1;

    real_1 = (-b)/(2*a);
    real_2 = (-b)/(2*a);

    imag_1 = (+delta)/(2*1);
    imag_2 = (-delta)/(2*1);
  }
  
  Complexo x_1 = Complexo (real_1, imag_1);

  Complexo x_2 = Complexo (real_2, imag_2);

  return make_pair(x_1, x_2);
}

int main () {
  cout << "Digite os coeficientes da equação f(x) = ax^2 + bx + c:" << endl;
  double a, b, c;
  cin >> a >> b >> c;
  auto r = raizes(a, b, c);
  cout << "(" << r.first.get_real() << ", " << r.first.get_imag() << ") "
       << "(" << r.second.get_real() << ", " << r.second.get_imag() << ")" << endl;
  return 0;
}