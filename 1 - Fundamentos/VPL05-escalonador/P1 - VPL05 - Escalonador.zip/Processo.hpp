#ifndef VPL5_PROCESSO_H
#define VPL5_PROCESSO_H

#include <iostream>
#include <string>

class Processo {
    private:
        int _id;
        std::string _nome;
        int _prioridade;
    
    public:
        Processo(int id, std::string nome, int prioridade);

        int get_id();

        std::string get_nome();

        int get_prioridade();
    
        void imprimir_dados();
};

#endif