#include <iostream>
#include <string>
#include <vector>

#include "Processo.hpp"
#include "ListaProcessos.hpp"

/*
ListaProcessos:
void adicionar_processo(Processo proc): Método que recebe um Processo e o adiciona na lista de maneira ORDENADA considerando a prioridade informada. A ordenação da prioridade deve ser DECRESCENTE, ou seja, do maior para o menor. Logo, um processo de prioridade 5 deve aparecer antes na lista que um processo com prioridade 1. Em caso de prioridades iguais, a ordem de inserção deve ser respeitada. 
Dica: A função insert da classe vector pode te ajudar a inserir um elemento na posição correta. 

Processo remover_processo_maior_prioridade(): remove da lista o processos de maior prioridade, para facilitar, o primeiro do vetor. Você deve retornar o processo removido. 
Dica: A função at da classe vector pode te ajudar acessar uma posição específica do vetor, e a função erase da classe vector pode te ajudar a remover um elemento do vetor.

Processo remover_processo_menor_prioridade(): remove da lista o processo de menor prioridade, para facilitar, o último elemento do vetor (não precisa respeitar a ordem de inserção). Você deve retornar o processo removido.
Dica: A função back() pode te ajudar acessar o último elemento de um vetor, e a função pop_back() pode te ajudar a remover o último elemento de um vetor. 

Processo remover_processo_por_id(int id): remove da lista um processo de acordo com o id e retorna o processo removido. Considere que o id sempre será válido, isto é, ele sempre existirá na lista quando a função for chamada.

void imprimir_lista(): imprime a situação atual da lista, ou seja, percorre toda a lista (do início para o final) e chama o método 'imprimir_dados()' de cada processo.
*/

ListaProcessos::ListaProcessos() {
    _lista = std::vector<Processo>{};
}

std::vector<Processo> ListaProcessos::get_lista() {
    return _lista;
}

void ListaProcessos::adicionar_processo(Processo proc) {
    unsigned int i;
    for (i = 0; i < _lista.size(); i++) {
        if (proc.get_prioridade() > _lista[i].get_prioridade()) {
            break;
        }
    }
    _lista.insert(_lista.begin() + i, proc);
} 

Processo ListaProcessos::remover_processo_maior_prioridade() {
    Processo processo_removido = _lista.front();
    _lista.erase(_lista.begin());
    return processo_removido;
}

Processo ListaProcessos::remover_processo_menor_prioridade() {
    Processo processo_removido = _lista.back();
    _lista.pop_back();
    return processo_removido;
}


Processo ListaProcessos::remover_processo_por_id(int id) {
    unsigned int i;
    for (i = 0; i < _lista.size(); i++) {
        if (_lista[i].get_id() == id) {
            break;
        }
    }
    Processo processo_removido = _lista[i];
    _lista.erase(_lista.begin() + i);
    return processo_removido;
}

void ListaProcessos::imprimir_lista() {
    for (Processo element : _lista) {
        element.imprimir_dados();
    }
}