// NÃO ALTERE ESSA LINHA
#include "avaliacao_basica_escalonador.hpp"
#include <iostream>
#include <string>


#include "Processo.hpp"
#include "ListaProcessos.hpp"


int main() {
    ListaProcessos lista;
    std::string input;
    std::cin >> input;

    while (!input.empty()) {

        if (input == "a") {
    //        std::cout << "entrou no primeiro if" << std::endl;
            std::string nome;
            int prioridade, id;
    
            std::cin >> id >> nome >> prioridade;
           // std::cout << nome << " " << prioridade << " " << id << std::endl;
    
            Processo p(id, nome, prioridade);
            lista.adicionar_processo(p);
        }
        else if (input == "m") lista.remover_processo_maior_prioridade();
        else if (input == "n") lista.remover_processo_menor_prioridade();
        else if (input == "r") {
            int input_id;
            std::cin >> input_id;
            lista.remover_processo_por_id(input_id);
        }
        else if (input == "p") lista.imprimir_lista();
        else if (input == "b") avaliacao_basica();
        
        // remove the data type std::string here
        input = "";
        std::cin >> input;
    }
    return 0;
}