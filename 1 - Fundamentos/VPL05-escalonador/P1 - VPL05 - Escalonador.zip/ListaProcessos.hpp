#ifndef VPL5_LISTAPROCESSOS_H
#define VPL5_LISTAPROCESSOS_H

#include <iostream>
#include <string>
#include <vector>

#include "Processo.hpp"

class ListaProcessos {
    private:
        std::vector<Processo> _lista;

    public:
        ListaProcessos();

        std::vector<Processo> get_lista();

        void adicionar_processo(Processo proc);
        
        Processo remover_processo_maior_prioridade();
        
        Processo remover_processo_menor_prioridade();

        Processo remover_processo_por_id(int id);
        
        void imprimir_lista();
};

#endif