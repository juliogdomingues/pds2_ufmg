#include <iostream>
#include <string>

#include "Processo.hpp"

/*
Especificações
Processo: 
Atributos: int id, std::string nome, int prioridade;
Processo(int id, std::string nome, int prioridade): Método construtor para a inicialização dos atributos.
void imprimir_dados(): Método que faz a impressão dos atributos no seguinte formato: "id nome prioridade", com uma quebra de linha ao final.
*/

Processo::Processo(int id, std::string nome, int prioridade) {
    _id = id;
    _nome = nome;
    _prioridade = prioridade;
}

int Processo::get_id() {
    return _id;
}

std::string Processo::get_nome() {
    return _nome;
}

int Processo::get_prioridade() {
    return _prioridade;
}

void Processo::imprimir_dados() {
    std::cout << _id << " " << _nome << " " << _prioridade << std::endl;
}
