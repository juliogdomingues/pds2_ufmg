#include <exception>
#include "fila.h"


struct No {
  int chave;
  No* proximo;
};

Fila::Fila() {
    tamanho_ = 0;
    primeiro_ = nullptr;
    ultimo_ = nullptr;
}

Fila::~Fila() {
    while (primeiro_ != nullptr) {
        No* proximo = primeiro_-> proximo;
        delete primeiro_;
        primeiro_ = proximo;
    }
}  

// Insere um elemento no fim da fila.
void Fila::Inserir(int k) {
    No* novo_no = new No{k, nullptr};
    if (tamanho_ == 0) {
        primeiro_ = novo_no;
    } else {
        No* ultimo = ultimo_;
        ultimo_->proximo = novo_no;
    }
    ultimo_ = novo_no;
    tamanho_++;
}

// Remove o elemento no início da fila.
// Lança uma exceção do tipo EmptyException caso a fila esteja vazia.
void Fila::RemoverPrimeiro() {
    if (tamanho_ == 0) throw ExcecaoFilaVazia();
    No* primeiro = primeiro_;
    primeiro_ = primeiro_->proximo;
    delete primeiro;
    tamanho_--;
}

// Retorna o elemento no início da fila.
// Lança uma exceção do tipo EmptyException caso a fila esteja vazia.
int Fila::primeiro() const {
    if (tamanho_ == 0) throw ExcecaoFilaVazia ();
    return primeiro_->chave;
}

// Retorna o elemento no fim da fila.
// Lança uma exceção do tipo EmptyException caso a fila esteja vazia.
int Fila::ultimo() const {
    if (tamanho_ == 0) throw ExcecaoFilaVazia ();
    No* ultimo = primeiro_;
    while (ultimo->proximo != nullptr) {
        ultimo = ultimo->proximo;
    }
    return ultimo->chave;
}

// Retorna o número de elementos na fila.
int Fila::tamanho() const {
    return tamanho_;
}