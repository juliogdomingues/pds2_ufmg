#include "fila_de_prioridade.h"

struct No {
    int prioridade;
    string nome;
    No* proximo;
    
    No(int p, string s) {
        prioridade = p;
        nome = s;
        proximo = nullptr;
    }
};

// Constrói uma fila vazia.
FilaDePrioridade::FilaDePrioridade() {
    tamanho_ = 0;
    primeiro_ = nullptr;
}

// Retorna o elemento de maior prioridade.
// PRECONDIÇÃO: a fila tem pelo menos um elemento.

string FilaDePrioridade::primeiro() const {
    if (tamanho_ < 1) return "";
    else {
        int maior_idade = primeiro_->prioridade;
        string nome_mais_velho = primeiro_->nome;
        No* atual = primeiro_->proximo;
        while (atual != nullptr) {
            if (atual->prioridade > maior_idade) {
                maior_idade = atual->prioridade;
                nome_mais_velho = atual->nome;
            }
            atual = atual->proximo;
        }
        return nome_mais_velho;
    }
}

// Retorna o número de elementos na fila.
int FilaDePrioridade::tamanho() const {
    return tamanho_;
}

// Testa se a fila está vazia.
bool FilaDePrioridade::vazia() const {
    if (tamanho_ == 0) return true;
    else return false;
}

// Remove o elemento de maior prioridade.
// PRECONDIÇÃO: a fila tem pelo menos um elemento.
void FilaDePrioridade::RemoverPrimeiro() {
    if (primeiro_ != nullptr) {
        No* temp = primeiro_;
        primeiro_ = primeiro_->proximo;
        delete temp;
        tamanho_--;
    }
}

// Insere um elemento s fila com prioridade p;
// OBS: Pode haver repetição de elementos.
// Neste caso, os elementos podem ter prioridades iguais ou diferentes. 
void FilaDePrioridade::Inserir(int p, string s) {
    No* novo_no = new No(p, s);
    if (vazia() || primeiro_ == nullptr || p > primeiro_->prioridade) {
        novo_no->proximo = primeiro_;
        primeiro_ = novo_no;
    } else {
        No* anterior = primeiro_;
        No* atual = primeiro_->proximo;
        while (atual != nullptr && p <= atual->prioridade) {
            anterior = atual;
            atual = atual->proximo;
        }
        anterior->proximo = novo_no;
        novo_no->proximo = atual;
    }
    tamanho_++;
}

// Remove todos os elementos da fila.
void FilaDePrioridade::Limpar() {
        while (tamanho_ > 0) {
        RemoverPrimeiro();
    }
}