#pragma once

#include <cassert>
#include <vector>


// DEFINIÇÃO DAS CLASSES DE EXCEÇÃO.

// Lançada quando o intervalo [inicio, fim] não contém nenhum índice.
struct ExcecaoIntervaloVazio {
  int inicio;  // Índice de início do arranjo que lançou a exceção.
  int fim;  // Índice de fim do arranjo que lançou a exceção.
};

// Lançada quando 'indice' não pertence a [inicio, fim].
struct ExcecaoIndiceInvalido {
  int inicio;  // Índice de início do arranjo que lançou a exceção.
  int fim;  // Índice de fim do arranjo que lançou a exceção.
  int indice;  // Índice inválido. 
};

// Lançada quando o valor de 'indice' é solicitado e o mesmo não foi previamente
// inicializado.
struct ExcecaoIndiceNaoInicializado {
  int indice;  // Índice do arranjo que não foi inicializado. 
};


// Define um vetor de qualquer Tipo cujos índices variam em
// qualquer intervalo, inclusive negativos.
template <class Tipo> 
class Vetor {
public:
  // Cria um vetor cujos índices variam de 'inicio' até 'fim'.
  // PRECONDIÇÃO: fim >= inicio.
  Vetor(int inicio, int fim);

  // Altera o valor do índice i.
  // PRECONDIÇÃO: i está dentro do intervalo de índices do vetor.
  void atribuir(int i, Tipo valor);

  // Retorna o valor do índice i.
  // PRECONDIÇÕES: 
  // (1) i está dentro do intervalo de índices do vetor.
  // (2) i foi inicializado anteriormente.
  Tipo valor(int i) const; 
  
private:
  int inicio_;  // Primeiro índice válido do vetor.
  int fim_;  // Último índice válido do vetor.
  std::vector<Tipo> elementos_;  // Elementos do vetor.
  std::vector<bool> inicializado_;  // Vetor de inicialização
};


// IMPLEMENTAÇÃO DOS MÉTODOS DA CLASSE.

template <class Tipo> 
Vetor<Tipo>::Vetor(int inicio, int fim) : 
  inicio_(inicio), 
  fim_(fim) {
    if (fim < inicio) throw ExcecaoIntervaloVazio{inicio, fim};
    
    int tamanho = fim - inicio + 1;
    elementos_.resize(tamanho);
    inicializado_.resize(tamanho, false);
}

template <class Tipo> 
void Vetor<Tipo>::atribuir(int i, Tipo valor) {
  if (i < inicio_ || i > fim_) throw ExcecaoIndiceInvalido{inicio_, fim_, i};
  int deslocamento = i - inicio_;
  elementos_[deslocamento] = valor;
  inicializado_[deslocamento] = true;
}

template <class Tipo> 
Tipo Vetor<Tipo>::valor(int i) const { 
  if (i < inicio_ || i > fim_) throw ExcecaoIndiceInvalido{inicio_, fim_, i};
  int deslocamento = i - inicio_;
  if (!inicializado_[deslocamento]) throw ExcecaoIndiceNaoInicializado{i};
  return elementos_[deslocamento];
}
