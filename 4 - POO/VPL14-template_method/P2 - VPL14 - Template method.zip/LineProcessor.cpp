#include <regex>
#include <math.h>
#include <string>
#include <vector>
#include <sstream>

#include "LineProcessor.hpp"

void LinePrinter::processaLinha(const std::string &str) {
  std::cout << str << std::endl;
}

bool ContadorPopRural::linhaValida(const std::string &str) const {
  // Neste exemplo usaremos expressoes regulares para verificar se uma linha
  // eh valida ou nao.
  //
  // Esta expressao regular eh formada por cinco partes. Cada uma dessas
  // partes eh um dos tres tipos de padrao regular abaixo:
  //
  // \\w+ eh qualquer palavra com um ou mais digitos, letras e sublinhas (_)
  // \\s* eh qualquer sequencia de zero ou mais espacos (inclui tab)
  // \\d+ eh qualquer sequencia de um ou mais digitos
  std::regex regularExpr("\\w+\\s*\\d+\\s*\\d+");

  // A funcao regex_match vai retornar verdadeiro se a string str casa-se com
  // a expressao regular que acabamos de criar:
  return std::regex_match(str, regularExpr);
}

void ContadorPopRural::processaLinha(const std::string &str) {
  //
  // Em geral eh mais facil ler dados de uma string se a string eh transformada
  // em um objeto do tipo stringstream:
  std::stringstream ss(str);
  //
  // Iremos ler os dados da string nestas tres variaveis abaixo:
  std::string nomePais;
  unsigned populacao, percUrbana;
  //
  // Como sabemos que a linha contem string int int, podemos fazer a leitura
  // facilmente usando o operador de streaming:
  ss >> nomePais >> populacao >> percUrbana;
  //
  // Note que precisamos arredondar o valor que serah impresso. O arredondamento
  // serah feito via a funcao floor. Ou seja, decimais serao sempre
  // arredondados para baixo:
  unsigned popRural = floor(populacao - (populacao * (percUrbana/100.0)));
  //
  // Uma vez encontrados os valores que precisam ser impressos, seguimos o
  // modelo do enunciado do exercicio:
  std::cout << popRural << " pessoas vivem no campo no " << nomePais <<
    std::endl;
}

bool ContadorNumNaturais::linhaValida(const std::string &str) const {
  // TODO: Implemente este metodo
    std::regex reg_std("^[0-9 ]*$");
    return std::regex_match(str, reg_std);
}

void ContadorNumNaturais::processaLinha(const std::string &str) {
  // TODO: Implemente este metodo:
    if (!linhaValida(str))
    {
        std::cout << "Linha inválida: " << str << std::endl;
        return;
    }

    std::istringstream palavra(str);
    unsigned int num;
    unsigned int somaLinha = 0;

    while (palavra >> num)
    {
        somaLinha += num;
    }

    std::cout << somaLinha << std::endl;
}

bool LeitorDeFutebol::linhaValida(const std::string &str) const {
  // TODO: Implemente este metodo
    std::regex reg_std("^\\s*[a-zA-Z]+\\s+[0-9]+\\s+[a-zA-Z]+\\s+[0-9]+\\s*$");
    return std::regex_match(str, reg_std);
}

void LeitorDeFutebol::processaLinha(const std::string &str) {
  // TODO: Implemente este metodo:
    std::string time1;
    unsigned int gols_time1;
    std::string time2;
    unsigned int gols_time2;

    if (linhaValida(str))
    {
        std::istringstream info(str);
        info >> time1 >> gols_time1 >> time2 >> gols_time2;
    }
    if (gols_time1 == gols_time2) std::cout << "Empate" << std::endl;
    if (gols_time1 > gols_time2) std::cout << "Vencedor: " << time1 << std::endl;
    if (gols_time1 < gols_time2) std::cout << "Vencedor: " << time2 << std::endl;
}

void ContadorDePalavras::processaLinha(const std::string &str) {
  // TODO: Implemente este metodo:
    std::string num_total;
    int contador = 0;
    std::istringstream info(str);
    while (info >> num_total)
    {
        contador++;
    }
    std::cout << contador << std::endl;
}

bool InversorDeFrases::linhaValida(const std::string &str) const {
  // TODO: Implemente este metodo
    std::regex reg_std("^[a-zA-Z ]*$");
    return std::regex_match(str, reg_std);
}

void InversorDeFrases::processaLinha(const std::string &str) {
// TODO: Implemente este método:
    if (!linhaValida(str))
    {
        std::cout << "Linha inválida: " << str << std::endl;
        return;
    }
    
    std::vector<std::string> palavras;
    std::istringstream fluxoLinha(str);
    std::string palavra;
    std::string strInvertida;
    
    while (fluxoLinha >> palavra)
    {
        palavras.push_back(palavra);
    }
    
    for (auto it = palavras.rbegin(); it != palavras.rend(); it++)
    {
        strInvertida += *it;
        strInvertida += " ";
    }
    
    std::cout << strInvertida << std::endl;
}

bool EscritorDeDatas::linhaValida(const std::string &str) const {
  std::string dateFormat = "\\s*\\d\\d?/\\d\\d?/\\d{4}";
  // TODO: Implemente este metodo
  // Note que você pode usar uma expressao regular como:
  // "\\s*\\d\\d?/\\d\\d?/\\d{4}" para saber se a linha eh valida:
    std::regex reg_std("\\s*\\d{1,2}/\\d{1,2}/\\d{4}\\s*");
    return std::regex_match(str, reg_std);
}

void EscritorDeDatas::processaLinha(const std::string &str) {
  // TODO: Implemente este metodo:
  // Lembre-se que as iniciais dos meses sao:
  // "Jan", "Fev", "Mar", "Abr", "Mai", "Jun", "Jul", "Ago", "Set", "Out",
  // "Nov", e "Dez".

    if (!linhaValida(str)) {
        std::cout << "Linha inválida: " << str << std::endl;
        return;
    }

    std::istringstream info(str);
    std::string data;
    std::getline(info, data);

    std::string dia, mes, ano;
    std::istringstream dataStream(data);
    std::getline(dataStream, dia, '/');
    std::getline(dataStream, mes, '/');
    std::getline(dataStream, ano);

    auto it = mapaMeses.find(mes);
    if (it != mapaMeses.end()) {
        std::cout << it->second << std::endl;
    } else {
        std::cout << "Mês inválido: " << mes << std::endl;
    }
}