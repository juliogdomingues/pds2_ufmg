#include "celular.hpp"

// TODO: Inicialize aqui sua variavel estatica. Caso tenha optado por essa
// solucao.

int proximo_codigo = 1; // Inicialização da variável estática


Celular::Celular(std::string modelo,
                 std::string fabricante,
                 int armazenamento,
                 int memoria,
                 double peso,
                 std::string cor,
                 int qtd,
                 float valor) {
  // TODO: Implemente este metodo
  _modelo = modelo;
  _fabricante = fabricante;
  _armazenamento = armazenamento;
  _memoria = memoria;
  _peso = peso;
  _cor = cor;
  _qtd = qtd;
  _valor = valor;
  _cod = proximo_codigo;
  proximo_codigo++;
}

int Celular::get_cod() {
    return _cod;
}

std::string Celular::get_fab() const {
    return _fabricante;
}

std::string Celular::get_mod() const {
    return _modelo;
}

int Celular::get_armaz() {
    return _armazenamento;
}

int Celular::get_ram() {
    return _memoria;
}

double Celular::get_peso() {
    return _peso;
}

std::string Celular::get_cor() {
    return _cor;
}

int Celular::get_qtd() {
    return _qtd;
}

void Celular::mod_qtd(int nova_qtd) {
    _qtd += nova_qtd;
}

float Celular::get_valor() {
    return _valor;
}

void Celular::desc_valor(float desconto) {
    _valor *= (1.0 - (desconto/100.0));
}

bool Celular::operator<(const Celular& other) {
  // TODO: Implemente este metodo. 
  // Preste atencao no exemplo que a descricao utilizada na ordenacao considera
  // a fabricante antes do modelo do celular
  if (this->get_fab() != other.get_fab()) {
    return this->get_fab() < other.get_fab(); // Ordena por fabricante primeiro
  } else {
    return this->get_mod() < other.get_mod(); // Ordena por modelo depois
  }
  return false;
}