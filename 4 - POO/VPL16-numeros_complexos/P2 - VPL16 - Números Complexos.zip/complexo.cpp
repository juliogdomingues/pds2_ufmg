#include "complexo.h"
#include <cmath>

Complexo::Complexo() : _real(0), _imag(0) {}

Complexo::Complexo(double a) : Complexo(a, 0) {}

Complexo::Complexo(double a, double b) : _real(a), _imag(b) {}

double Complexo::real() const {
    return _real;
}

double Complexo::imag() const {
    return _imag;
}

bool Complexo::operator==(Complexo x) const {
    static const double epsilon = 1E-6;
    
    return fabs(x._real - _real) < epsilon && fabs(x._imag - _imag) < epsilon;
}

void Complexo::operator=(Complexo x) {
    _real = x._real;
    _imag = x._imag;
}

double Complexo::modulo() const {
    return sqrt(_real * _real + _imag * _imag);
}

Complexo Complexo::conjugado() const {
    return Complexo(_real, -_imag);
}

Complexo Complexo::operator-() const {
    return Complexo(-_real, -_imag);
}

Complexo Complexo::inverso() const {
    double divisor = _real * _real + _imag * _imag;
    return Complexo(_real / divisor, -_imag / divisor);
}

Complexo Complexo::operator+(Complexo y) const {
    return Complexo(_real + y._real, _imag + y._imag);
}

Complexo Complexo::operator-(Complexo y) const {
    return Complexo(_real - y._real, _imag - y._imag);
}

Complexo Complexo::operator*(Complexo y) const {
    double a = _real * y._real - _imag * y._imag;
    double b = _real * y._imag + _imag * y._real;
    return Complexo(a, b);
}

Complexo Complexo::operator/(Complexo y) const {
    double divisor = y._real * y._real + y._imag * y._imag;
    double a = (_real * y._real + _imag * y._imag) / divisor;
    double b = (_imag * y._real - _real * y._imag) / divisor;
    return Complexo(a, b);
}