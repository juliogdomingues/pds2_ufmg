#include "produto.hpp"

int Produto::getQtd() const
{
    // TODO: Implemente este metodo
    return m_qtd;
}

float Produto::getValor() const
{
    // TODO: Implemente este metodo
    return m_valor_unitario;
}